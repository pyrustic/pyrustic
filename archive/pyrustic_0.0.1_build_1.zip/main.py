from core.pyrushell import PyruShell
PyruShell().cmdloop()
