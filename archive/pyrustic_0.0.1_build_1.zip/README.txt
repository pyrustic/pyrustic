Pyrustic 0.0.1 build 1
March 20, 2020


Pyrustic is a project which aims to modestly apply the philosophy of "building great things with few resources". It will therefore be a question of being anti-hype at a time when one gleefully uses a bazooka to kill a fly.


PYRUSTIC FRAMEWORK

The heart of the Pyrustic project is a framework soberly titled Pyrustic Framework. It is a new minimalist framework for creating software in Python. Pyrustic Framework is proudly based on Tkinter as GUI toolkit and on SQLite as the database engine.

A command line tool was created to help develop software based on the Pyrustic Framework. The tool is soberly titled Pyrustic Platform Shell and is available on Github.


PYRUSTIC COMES WITH BATTERIES INCLUDED: TABLE, SCROLLBOX, TOAST ...

Pyrustic Framework comes with some new home-made widgets (mega-widgets, to be precise) that might interest the developer during the development of the GUI. For the moment, these are Table, Scrollbox, Toast, Choice and Dialog.


SQLUNATIC AS PROOF OF CONCEPT

SQLunatic is a graphical SQLite database administration tool. You can create new databases, execute SQL scripts contained in files, view the contents of your SQLite databases and execute entered SQL queries. SQLunatic is developed with Pyrustic Framework as an example of what can be done with Pyrustic Framework.


WHAT IS NEXT ?

The Pyrustic project is at the very beginning of its hypothetical adventure. Barely a class has benefited from unit tests. The documentation is still precarious and all versions below 1.0.0 will be considered to be Beta at best. Lots of good things are yet to come to make Pyrustic a cool project in the Python Universe.


HOW TO START ?
- Read the file 'what_is_pyrustic_framework.txt'
- Execute 'main.py' or 'PYRUSTIC.py' then type 'tutorial' in the shell

Pyrustic is on Github !
https://github.com/pyrustic
