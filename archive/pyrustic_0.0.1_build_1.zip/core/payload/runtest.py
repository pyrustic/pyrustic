import pyrustic.runtest

