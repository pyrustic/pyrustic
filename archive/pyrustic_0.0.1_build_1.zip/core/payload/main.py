from pyrustic.app import App
import about
import os.path


app = App()
app.start()

