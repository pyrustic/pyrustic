data ="""
import about


class {}:

    def __init__(self):
        pass

"""
