data ="""
import sqlite3 as sqlite
from pyrustic.dao import Dao
import about


class {}:

    def __init__(self):
        # You can use pyrustic.dao.Dao to interact with your sqlite database
        # Please read ROOT/pyrustic/dao.py to discover how to use it
        pass

"""
