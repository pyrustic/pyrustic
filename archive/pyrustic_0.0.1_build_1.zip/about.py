import os.path
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
VERSION = "0.0.1"
BUILD = "1"
if __name__ == "__main__":
    print("Pyrustic Shell ", VERSION, " Build ", BUILD)
